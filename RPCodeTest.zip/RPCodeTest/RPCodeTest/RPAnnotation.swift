//
//  RPAnnotation.swift
//  RPCodeTest
//
//  Created by Sneha Rao on 4/13/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

import UIKit

class RPAnnotation: NSObject {
    
    private (set) var title, descr : String?
    private override init() {
        super.init()
    }
    
    init(rpAnnotation : NSDictionary?) {
        title = rpAnnotation!["title"] as? String ?? ""
        descr = rpAnnotation!["decr"] as? String ?? ""
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init()
        title = aDecoder.decodeObject(forKey: "title") as? String
        descr = aDecoder.decodeObject(forKey: "decr") as? String
    }
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encode(title, forKey: "title")
        aCoder.encode(descr, forKey: "descr")
    }
    
    func toDictionary() -> NSDictionary {
        
        let dict =  NSMutableDictionary()
        dict.setValue(self.title, forKey: "title")
        dict.setValue(self.descr, forKey: "commentID")
        return dict
    }
    
    
}
