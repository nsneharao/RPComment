//
//  ViewController.swift
//  RPCodeTest
//
//  Created by Sneha Rao on 4/13/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        IMFDataManager.initialize(withUrl: "ServerUrl")
        
    }
    func saveRCComment(){
        let insat = RPComment(rpComment: ["comment":"Test comment",
                                           "commentID":"123",
                                           "commentDate":"1-4-2017",
                                           "Name":"RPComment"])
        
        RemoteStore.saveinstancetoCloud(Comment: insat, Classname: NSStringFromClass(RPComment.classForCoder())) { (result, errMsg) in
            if errMsg == nil {
                print(result ?? "")
            }else{
                print(errMsg ?? "UNKNOWN ERROR")
            }
        }
        
        //        HTTP_Status: 201
        //        JSON Body: {
        //            id = 6dfde55449915faa92c471bd0ecd89d6;
        //            ok = 1;
        //            rev = "1-419dfa2a14026c4c18545723e8f990fa";
        //        }
        //        saved revision: <RPCodeTest.RPComment: 0x7f91f1c6e2f0>
        
    }
    func saveRPAnnotation(){
        let insat = RPAnnotation(rpAnnotation: ["title":"Annotation title",
                                                 "decription":"this object will save via remote store"])
        RemoteStore.saveinstancetoCloud(Comment: insat, Classname: NSStringFromClass(RPAnnotation.classForCoder())) { (result, errMsg) in
            if errMsg == nil {
                print(result ?? "")
            }else{
                print(errMsg ?? "UNKNOWN ERROR")
            }
        }
        //        HTTP_Status: 201
        //        JSON Body: {
        //            id = 6dfde55449915faa92c471bd0ecd89d6;
        //            ok = 1;
        //            rev = "1-419dfa2a14026c4c18545723e8f990fa";
        //        }
        //        saved revision: <RPCodeTest.RPAnnotation: 0x7f91f1c6e2f0>
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
