//
//  RPComment.swift
//  RPCodeTest
//
//  Created by Sneha Rao on 4/13/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

import UIKit

class RPComment: NSObject {
    
    private (set) var comment, Id , date ,UserName : String?
    
    private override init() {
        super.init()
    }
    
    init(rpComment : NSDictionary?) {
        
        comment = rpComment?.value(forKey: "comment") as? String ?? ""
        Id = rpComment?.value(forKey: "commentID") as? String ?? ""
        date = rpComment?.value(forKey: "commentDate") as? String ?? ""
        UserName = rpComment?.value(forKey: "Name") as? String ?? ""
        
    }
    required init(coder aDecoder: NSCoder) {
        super.init()
        comment = aDecoder.decodeObject(forKey: "comment") as? String
        Id = aDecoder.decodeObject(forKey: "commentID") as? String
        date = aDecoder.decodeObject(forKey: "commentDate") as? String
        UserName = aDecoder.decodeObject(forKey: "Name") as? String
    }
    
    func encodeWithCoder(aCoder: NSCoder) {
        aCoder.encode(comment, forKey: "comment")
        aCoder.encode(Id, forKey: "commentID")
        aCoder.encode(date, forKey: "commentDate")
        aCoder.encode(UserName, forKey: "Name")
        
    }
    
    func toDictionary() -> NSDictionary {
        let dict =  NSMutableDictionary()
        dict.setValue(self.comment, forKey: "comment")
        dict.setValue(self.Id, forKey: "commentID")
        dict.setValue(self.date, forKey: "commentDate")
        dict.setValue(self.UserName, forKey: "Name")
        return dict
    }
}
