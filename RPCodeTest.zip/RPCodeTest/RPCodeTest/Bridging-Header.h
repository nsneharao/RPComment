//
//  Bridging-Header.h
//  RPCodeTest
//
//  Created by Sneha Rao on 4/13/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

#ifndef Bridging_Header_h
#define Bridging_Header_h


#import <CloudantToolkit/CloudantToolkit.h>
#import <CloudantSync.h>
#import <IMFData/IMFData.h>

#endif /* Bridging_Header_h */
