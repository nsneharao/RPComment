//
//  RemoteStore.swift
//  RPCodeTest
//
//  Created by Sneha Rao on 4/13/17.
//  Copyright © 2017 Sneha Rao. All rights reserved.
//

import UIKit

typealias remoteResponseBlock = (Any?,String?)->Void

let dbName = "R&PCodeTest"

class RemoteStore: NSObject {
    
    class func saveinstancetoCloud(Comment : NSObject ,Classname : String ,responseHander:@escaping remoteResponseBlock){
        
        var remoteStore:CDTStore!
        
        // initialize an instance of the IMFDataManager
        let manager:IMFDataManager = IMFDataManager.sharedInstance()
        
        
        // Create remote store
        manager.remoteStore(dbName) { (store, err) in
            if err != nil {
                
            }else{
                remoteStore = store
                print(remoteStore.name)
                // Register class with remote store
                remoteStore.mapper.setDataType(Classname, forClassName: Classname)
                // Actually save the object to Bluemix
                remoteStore.save(Comment, completionHandler: { (result, err) in
                    if err != nil {
                        //Handle error
                        responseHander(nil,err?.localizedDescription)
                    } else {
                        responseHander(result,nil)
                    }
                })
                
            }
        }
    }
}
